<?php
/**
 * The sidebar containing the front page widget areas
 *
 * If no active widgets are in either sidebar, hide them completely.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */

/*
 * The front page widget area is triggered if any of the areas
 * have widgets. So let's check that first.
 *
 * If none of the sidebars have widgets, then let's bail early.
 */

// If we get this far, we have widgets. Let do this.







?>



<div class="col-xs-12 col-md-3 sidebar-right no-padding">
        <section class="rightmenu-first">
          <div class="col-md-12">
            <div class="btn-group">
              <button type="button" class="btn btn-default dropdown-toggle btn-ash" data-toggle="dropdown"> Action <span class="caret"></span> </button>
              <ul class="dropdown-menu" role="menu">
                <li><a href="#">Action</a></li>
                <li><a href="#">Another action</a></li>
                <li><a href="#">Something else here</a></li>
                <li class="divider"></li>
                <li><a href="#">Separated link</a></li>
              </ul>
            </div>
            <div class="btn-group">
              <button type="button" class="btn btn-default dropdown-toggle btn-ash" data-toggle="dropdown"> Action <span class="caret"></span> </button>
              <ul class="dropdown-menu" role="menu">
                <li><a href="#">Action</a></li>
                <li><a href="#">Another action</a></li>
                <li><a href="#">Something else here</a></li>
                <li class="divider"></li>
                <li><a href="#">Separated link</a></li>
              </ul>
            </div>
          </div>
        </section>
        <section class="rightmenu-second">
        
          <div class="col-md-12">
            <button type="button" class="btn btn-primary floud-btn btn-megento" > Action </button>
          </div>
        </section>
        <section class="rightmenu-three">
        <p class="centre-title">Aditional Actions</p>
          <ul class="nav additional-action-menu">
            <li> <a href="#download-bootstrap">
              <div class="sidebar-link"><i class="fa fa-sun-o fa-2 sub-title"></i><span class="menu-text">Home Abouth homesss Home Abouth homesss</span></div>
              </a> </li>
            <li> <a href="#download-bootstrap">
              <div class="sidebar-link"><i class="fa fa-sun-o fa-2 sub-title"></i><span class="menu-text">Home Abouth homesss Home Abouth homesss</span></div>
              </a> </li>
            <li> <a href="#download-bootstrap">
              <div class="sidebar-link"><i class="fa fa-sun-o fa-2 sub-title"></i><span class="menu-text">Home Abouth homesss Home Abouth homesss</span></div>
              </a> </li>
            <li> <a href="#download-bootstrap">
              <div class="sidebar-link"><i class="fa fa-sun-o fa-2 sub-title"></i><span class="menu-text">Home Abouth homesss Home Abouth homesss</span></div>
              </a> </li>
          </ul>
        </section>
      </div>