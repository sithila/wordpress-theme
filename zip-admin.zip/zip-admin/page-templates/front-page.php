<?php
/**
 * Template Name: Front Page Template
 * @package WordPress
 * @subpackage Zip-Admin
 * @since Zip-Admin 1.0
 */

get_header(); ?>

<?php get_sidebar( 'left' ); ?>

<div class="col-xs-12 col-md-7">
        <section class="">
          <div class="row">
            <div class="col-md-12 content-top-btn-area">
              <button type="button" class="btn btn-default">Default</button>
              <button type="button" class="btn btn-primary">Primary</button>
            </div>
          </div>
        </section>
        <section class="">
          
          
           <div id="main">
    <!-- angular templating -->
    
    
    
    <div class="row">
            <div class="col-md-4 no-padding vertical-menu2">
              <ul class="nav">
                <li class="active"> <a href="#download-bootstrap">
                  <div class="sidebar-link"><i class="fa fa-sun-o fa-2 sub-title"></i><span class="menu-text">Home Abouth homesss Home Abouth homesss</span></div>
                  </a> </li>
                <li> <a href="#download-bootstrap">
                  <div class="sidebar-link"><i class="fa fa-sun-o fa-2 sub-title"></i><span class="menu-text">Home Abouth homesss Home Abouth homesss</span></div>
                  </a> </li>
                <li> <a href="#download-bootstrap">
                  <div class="sidebar-link"><i class="fa fa-sun-o fa-2 sub-title"></i><span class="menu-text">Home Abouth homesss Home Abouth homesss</span></div>
                  </a> </li>
                <li> <a href="#download-bootstrap">
                  <div class="sidebar-link"><i class="fa fa-sun-o fa-2 sub-title"></i><span class="menu-text">Home Abouth homesss Home Abouth homesss</span></div>
                  </a> </li>
              </ul>
            </div>
            <div class="col-md-8 mid-content-area">
            
            
            <div id="primary" class="site-content">
		<div id="content" role="main">

			<?php while ( have_posts() ) : the_post(); ?>
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="entry-page-image">
						<?php the_post_thumbnail(); ?>
					</div><!-- .entry-page-image -->
				<?php endif; ?>

				<?php get_template_part( 'content', 'page' ); ?>

			<?php endwhile; // end of the loop. ?>

		</div><!-- #content -->
	</div><!-- #primary -->
            
            
              
              
             
              
            </div>
          </div>
    
    
    
    
    
    
    
    
    
    
    
    
	
    
 
   <div ng-view></div>  
  </div>
          
          
          
        </section>
      </div>   
    
<?php get_sidebar( 'right' ); ?>

<?php /*?><?php get_sidebar( 'front' ); ?><?php */?>
<?php get_footer(); ?>