$( document ).ready(function() {
							 
var columnHeight = $("#main").outerHeight();

$('.sidebar').height(columnHeight  + 60);
$('.sidebar-right').height(columnHeight  + 60);

//var menutext = $( ".main-navigation-left ul li a" ).text()
//$( ".main-navigation-left ul li a" ).before( "<div class='sidebar-link'><i class='fa fa-sun-o'></i>" );
//$( ".main-navigation-left ul li a" ).after( "</div> " );

$(function() {
    $('.main-navigation-left ul li').each(function() {
      //var text = $(this).text();  
      var menutext = $(this).find('a').text();
	  $(this).find('a').html("<div class='sidebar-link'><i class='fa fa-sun-o'></i>"+ menutext  +"</div> ");
    });
});

							 
$('#elem').popover();

$("#elem").on('show.bs.popover',function () {
    $('.popover.in').remove();
});

$('[data-toggle="popover"]').popover();

$('body').on('click', function (e) {
    //only buttons
    if ($(e.target).data('toggle') !== 'popover'
        && $(e.target).parents('.popover.in').length === 0) { 
        $('[data-toggle="popover"]').popover('hide');
    }
    //buttons and icons within buttons
    /*
    if ($(e.target).data('toggle') !== 'popover'
        && $(e.target).parents('[data-toggle="popover"]').length === 0
        && $(e.target).parents('.popover.in').length === 0) { 
        $('[data-toggle="popover"]').popover('hide');
    }
    */
});



});
