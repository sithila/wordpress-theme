<?php
/**
 * The template for displaying Category pages
 *
 * Used to display archive-type pages for posts in a category.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */

get_header(); ?>

<?php get_sidebar( 'left' ); ?>


<div class="col-xs-12 col-md-7">
        <section class="">
          <div class="row">
            <div class="col-md-12 content-top-btn-area">
              <button type="button" class="btn btn-default">Default</button>
              <button type="button" class="btn btn-primary">Primary</button>
            </div>
          </div>
        </section>
        <section class="">
          
          
           <div id="main">
    <!-- angular templating -->
    <div class="row">
            <div class="col-md-4 no-padding vertical-menu2">
              <ul class="nav">
                <li class="active"> <a href="#download-bootstrap">
                  <div class="sidebar-link"><i class="fa fa-sun-o fa-2 sub-title"></i><span class="menu-text">Home Abouth homesss Home Abouth homesss</span></div>
                  </a> </li>
                <li> <a href="#download-bootstrap">
                  <div class="sidebar-link"><i class="fa fa-sun-o fa-2 sub-title"></i><span class="menu-text">Home Abouth homesss Home Abouth homesss</span></div>
                  </a> </li>
                <li> <a href="#download-bootstrap">
                  <div class="sidebar-link"><i class="fa fa-sun-o fa-2 sub-title"></i><span class="menu-text">Home Abouth homesss Home Abouth homesss</span></div>
                  </a> </li>
                <li> <a href="#download-bootstrap">
                  <div class="sidebar-link"><i class="fa fa-sun-o fa-2 sub-title"></i><span class="menu-text">Home Abouth homesss Home Abouth homesss</span></div>
                  </a> </li>
              </ul>
            </div>
            <div class="col-md-8 mid-content-area">
              
    
    
    
	<section id="primary" class="site-content">
		<div id="content" role="main">

		<?php if ( have_posts() ) : ?>
			<header class="archive-header">
				<h1 class="archive-title"><?php printf( __( 'Category Archives: %s', 'twentytwelve' ), '<span>' . single_cat_title( '', false ) . '</span>' ); ?></h1>

			<?php if ( category_description() ) : // Show an optional category description ?>
				<div class="archive-meta"><?php echo category_description(); ?></div>
			<?php endif; ?>
			</header><!-- .archive-header -->

			<?php
			/* Start the Loop */
			while ( have_posts() ) : the_post();

				/* Include the post format-specific template for the content. If you want to
				 * this in a child theme then include a file called called content-___.php
				 * (where ___ is the post format) and that will be used instead.
				 */
				get_template_part( 'content', get_post_format() );

			endwhile;

			twentytwelve_content_nav( 'nav-below' );
			?>

		<?php else : ?>
			<?php get_template_part( 'content', 'none' ); ?>
		<?php endif; ?>

		</div><!-- #content -->
	</section><!-- #primary -->
    
     
              
            </div>
          </div>
    
    
    
    
    
    
    
    
    
    
    
    
	
    
 
   <div ng-view></div>  
  </div>
          
          
          
        </section>
      </div>   
    
<?php get_sidebar( 'right' ); ?>    
    

<?php /*?><?php get_sidebar(); ?><?php */?>
<?php get_footer(); ?>