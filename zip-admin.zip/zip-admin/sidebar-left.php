<?php
/**
 * The sidebar containing the front page widget areas
 *
 * If no active widgets are in either sidebar, hide them completely.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */

/*
 * The front page widget area is triggered if any of the areas
 * have widgets. So let's check that first.
 *
 * If none of the sidebars have widgets, then let's bail early.
 */

// If we get this far, we have widgets. Let do this.







?>



<div class="col-xs-12 col-md-2 sidebar">

<nav id="site-navigation" class="main-navigation-left" role="navigation">
			<?php /*?><h3 class="menu-toggle"><?php _e( 'Menu', 'twentytwelve' ); ?></h3><?php */?>
			<?php /*?><a class="assistive-text" href="#content" title="<?php esc_attr_e( 'Skip to content', 'twentytwelve' ); ?>"><?php _e( 'Skip to content', 'twentytwelve' ); ?></a><?php */?>
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'main-navigation-left' ) ); ?>
		</nav>


       <?php /*?> <ul class="nav main-left-nav">
          <li> <a href="#home">
            <div class="sidebar-link"><i class="fa fa-sun-o"></i> Home</div>
            </a> </li>
          <li> <a href="#component">
            <div class="sidebar-link"><i class="fa fa-wrench"></i> Component</div>
            </a> </li>
          <li> <a href="#contact">
            <div class="sidebar-link"><i class="fa fa-phone"></i> Contact</div>
            </a> </li>
          <li> <a href="#java-script">
            <div class="sidebar-link"><i class="fa fa-puzzle-piece"></i> Java Script</div>
            </a> </li>

             <li> <a href="#charts">
            <div class="sidebar-link"><i class="fa fa-bar-chart-o"></i> Chsrts</div>
            </a> </li>
             <li> <a href="#html5charts">
            <div class="sidebar-link"><i class="fa fa-bar-chart-o"></i>HTML5 Chsrts</div>
            </a> </li>
          <li> <a href="#phones">
            <div class="sidebar-link"><i class="fa fa-sun-o"></i> Phones</div>
            </a> </li>
        </ul><?php */?>
        <ul class="nav">
          <li>
            <p>Overall</p>
            <div class="progress small-progress-bar ">
              <div class="progress-bar vilot-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"> 60% </div>
            </div>
          </li>
          <li>
            <p>Overall</p>
            <div class="progress small-progress-bar">
              <div class="progress-bar red-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"> 60% </div>
            </div>
          </li>
          <li>
            <p>Overall</p>
            <div class="progress small-progress-bar">
              <div class="progress-bar green-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"> 60% </div>
            </div>
          </li>
        </ul>
      </div>