<?php
/**
 * The template for displaying the footer
 * @package WordPress
 * @subpackage Zip-Admin
 * @since Zip-Admin 1.0
 */
?>
	 </div>
  </main> <!-- #main .wrapper -->
  
  
   <footer>
    <div class="container">
      <p> Admin with anguler and bootstrap &copy; Sithila Sandaruwan 2014. </p>
      <p> Twitter Bootstrap ,anguler Js &copy; </p>
    </div>
  </footer>
  
	<?php /*?><footer id="colophon" role="contentinfo">
		<div class="site-info">
			<?php do_action( 'twentytwelve_credits' ); ?>
			<a href="<?php echo esc_url( __( 'http://wordpress.org/', 'twentytwelve' ) ); ?>" title="<?php esc_attr_e( 'Semantic Personal Publishing Platform', 'twentytwelve' ); ?>"><?php printf( __( 'Proudly powered by %s', 'twentytwelve' ), 'WordPress' ); ?></a>
		</div><!-- .site-info -->
	</footer><!-- #colophon --><?php */?>
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>