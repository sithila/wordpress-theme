<?php
/**
 * The Template for displaying all single posts
 *
 * @package WordPress
 * @subpackage Zip-Admin
 * @since Zip-Admin 1.0
 */

get_header(); ?>

<?php get_sidebar( 'left' ); ?>

  <div class="col-xs-12 col-md-7">
        <section class="">
          <div class="row">
            <div class="col-md-12 content-top-btn-area">
              <button type="button" class="btn btn-default">Default</button>
              <button type="button" class="btn btn-primary">Primary</button>
            </div>
          </div>
        </section>
        <section class="">
          
          
           <div id="main">
    <!-- angular templating -->
	<div id="primary" class="site-content">
		<div id="content" role="main">

			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'content', get_post_format() ); ?>

				<nav class="nav-single">
					<h3 class="assistive-text"><?php _e( 'Post navigation', 'twentytwelve' ); ?></h3>
					<span class="nav-previous"><?php previous_post_link( '%link', '<span class="meta-nav">' . _x( '&larr;', 'Previous post link', 'twentytwelve' ) . '</span> %title' ); ?></span>
					<span class="nav-next"><?php next_post_link( '%link', '%title <span class="meta-nav">' . _x( '&rarr;', 'Next post link', 'twentytwelve' ) . '</span>' ); ?></span>
				</nav><!-- .nav-single -->

				<?php comments_template( '', true ); ?>

			<?php endwhile; // end of the loop. ?>

		</div><!-- #content -->
	</div><!-- #primary -->
    
   
    <div ng-view></div>  
  </div>
          
          
          
        </section>
      </div>    

 <?php get_sidebar( 'right' ); ?>

<?php /*?><?php get_sidebar(); ?><?php */?>
<?php get_footer(); ?>